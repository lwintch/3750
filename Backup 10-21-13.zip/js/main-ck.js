//On Load
$(function(){$("#toggleGridOff").click(function(){$(".cell").css("border-color","transparent")});$("#toggleGridOn").click(function(){$(".cell").css("border","1px solid #999")})});